# VoiceOver

Backtalk with the sounds and haptics of VoiceOver on iOS 18, taken from
VoiceOverTouch.app in iOS 18.6.2. See `NOTICE.txt` for who owns them.

As on iOS, gestures play no sound and controls have no sounds of their own, so
Backtalk still says what kind of control each one is.

## Sounds

Every sound is one of Apple's AIFF files rewritten as WAV, sample for sample:
22.05 kHz, 16-bit, stereo, unchanged otherwise.

| Backtalk sound | Plays for | Apple's file |
| --- | --- | --- |
| `focus` | Focus on an item | `Focus.aiff` |
| `focus_actionable` | Focus on an actionable item | `Interactable.aiff` |
| `view_entered` | Touching an empty area | `EmptySpace.aiff` |
| `tick` | Click | `Select.aiff` |
| `long_clicked` | Long press | `TripleClick.aiff` |
| `scroll_tone` | Scroll | `ScrollPage.aiff` |
| `chime_up` | Entering a list | `InteractIn.aiff` |
| `chime_down` | Leaving a list | `InteractOut.aiff` |
| `complete` | Action done or end reached | `WrapBoundary.aiff` |
| `window_state` | Window change | `ScreenChange.aiff` |
| `typo` | Spelling error | `NotFound.aiff` |
| `hyperlink` | Link | `LinkBegin.aiff` |
| `formatting` | Formatted text | `Capitals.aiff` |
| `screen_off` | Screen off | `ScreenOff.aiff` |
| `rotor_next` | Next setting | `RotorRight.aiff` |
| `rotor_previous` | Previous setting | `RotorLeft.aiff` |
| `keyboard_show` | Keyboard shown | `KeyboardUp.aiff` |
| `keyboard_hide` | Keyboard hidden | `KeyboardDown.aiff` |
| `direct_touch_enter` | Direct touch on | `TrackingOn.aiff` |
| `direct_touch_exit` | Direct touch off | `TrackingOff.aiff` |
| `wrap_forward` | Wrapped to the first item | `WrapForward.aiff` |
| `wrap_back` | Wrapped to the last item | `WrapBack.aiff` |
| `loading` | Loading | `WebPageLoadingInProgress.aiff` |
| `browse_mode_on_v4_2` | Browse mode on | `DrawerOpening.aiff` |
| `browse_mode_off_v4_2` | Browse mode off | `DrawerClosing.aiff` |
| `radial_menu` | Circle menu | `VOTOrbSound1-OrbHW.aiff` |
| `display_connected` | Braille display connected | `BrailleDisplayConnected.aiff` |
| `display_disconnected` | Braille display disconnected | `BrailleDisplayDisconnected.aiff` |
| `double_beep` | Braille command failed | `BrailleChordFailed.aiff` |
| `turn_on` | Braille auto scroll on | `TriggerSoundOn.aiff` |
| `turn_off` | Braille auto scroll off | `TriggerSoundOff.aiff` |
| `calibration_done` | Braille keyboard calibrated | `BSICalibration.aiff` |
| `braille_keyboard_character` | Braille keyboard: character | `BSITyping.aiff` |
| `braille_keyboard_space` | Braille keyboard: space | `BSISpace.aiff` |
| `braille_keyboard_delete` | Braille keyboard: delete | `BSIDeletion.aiff` |
| `braille_keyboard_new_line` | Braille keyboard: new line | `BSICarriageReturn.aiff` |

`gesture_begin` and `gesture_end` are set to no sound, because VoiceOver plays
none for gestures.

`screen_on` is left alone, so it stays silent as Backtalk has it, since
VoiceOver has no sound for it.

Nine of these have no counterpart in VoiceOver and are the nearest thing Apple
ships rather than an exact match: `tick`, `long_clicked`, `complete`, `typo`,
`formatting`, `direct_touch_enter`, `direct_touch_exit`, `browse_mode_on_v4_2`
and `browse_mode_off_v4_2`. Replace any of them under **Sounds** in the theme's
settings if another one suits you better.

## Vibrations

The vibrations come from Apple's `.ahap` haptic patterns in the same app.
Apple's intensity became Backtalk's strength, and Apple's sharpness chose the
haptic primitive: sharp taps became `tick`, middling ones `click` and dull ones
`low_tick`. The two decaying buzzes, for a window change and the screen turning
off, became their intensity envelopes with a `quick_fall`.

| Backtalk vibration | Apple's pattern |
| --- | --- |
| `focus` | `DidFocusOnElement.ahap` |
| `focus_actionable` | `IsInteractable.ahap` |
| `tick` | `DidActivateElement.ahap` |
| `long_clicked` | `DidReorderItem.ahap` |
| `scroll_tone` | `DidScrollByPage.ahap` |
| `chime_up` | `FolderDidOpen.ahap` |
| `chime_down` | `FolderDidClose.ahap` |
| `complete` | `BoundaryEncountered.ahap` |
| `window_state` | `ScreenDidChange.ahap` |
| `screen_off` | `ScreenDidTurnOff.ahap` |
| `loading` | `ItemIsLoading.ahap` |
| `typo` | `NoResultsFound.ahap` |
| `direct_touch_on` | `DidBeginPassthrough.ahap` |
| `announcement` | `NotificationDidAppear.ahap` |

Apple ships an empty haptic file where VoiceOver means to stay still, so
`long_clicked`, `chime_up` and `chime_down` have no vibration here.

VoiceOver also has haptics for the rotor, for wrapping, and for the keyboard
showing and hiding, but those sounds have no vibration in Backtalk, so a theme
cannot give them one. Every other vibration stays Backtalk's own.
