# VoiceOver

Backtalk with the sounds and haptics of VoiceOver on iOS 18, taken from
VoiceOverTouch.app in iOS 18.6.2. See `NOTICE.txt` for who owns them.

As on iOS, gestures play no sound and controls have no sounds of their own, so
Backtalk still says what kind of control each one is.

## Sounds

Every sound is one of Apple's AIFF files rewritten as WAV: 22.05 kHz, 16-bit,
mono. Apple ships a mono cut of each sound beside the stereo one, and that is
the one used here, both because it is half the size and because Backtalk's 3D
audio can only place a sound that is not already in two channels.

Apple mixes these for the iPhone's own speaker, where they peak anywhere from
-1 to -27 dB and the quiet ones are easy to miss on Android, so each one is
turned up. A sound is lifted until its loudest sample sits 1 dB below full
scale, which cannot clip, except that nothing is lifted by more than 12 dB, so
that the quiet ones stay quieter than the ones that play on every swipe. They
now peak between -15 and -1 dB, where before it was -27 to -1.

Which file goes with which event is not guesswork: VoiceOver keeps the table in
`-[VOSDefaultSoundPack eventToSoundFilenameMapping]` inside
`VoiceOverServices`, and it was read out of that binary. The **VoiceOver event**
column is Apple's own name for the event the sound belongs to.

| Backtalk sound | Plays for | VoiceOver event | Apple's file |
| --- | --- | --- | --- |
| `focus` | Focus on an item | `DidFocusOnElement` | `ElementBorder.aiff` |
| `focus_actionable` | Focus on an actionable item | — | `ElementBorder.aiff` |
| `view_entered` | Touching an empty area | `NoItemExists` | `EmptySpace.aiff` |
| `tick` | Click | `DidActivateElement` | `Select.aiff` |
| `long_clicked` | Long press | `DidBeginPassthrough` | `Drill.aiff` |
| `scroll_tone` | Scroll | `DidScrollByPage` | `ScrollPage.aiff` |
| `chime_up` | Entering a list | `InteractIn` | `InteractIn.aiff` |
| `chime_down` | Leaving a list | `InteractOut` | `InteractOut.aiff` |
| `complete` | Action done or end reached | `BoundaryEncountered` | `WrapBoundary.aiff` |
| `window_state` | Window change | `ScreenDidChange` | `ScreenChange.aiff` |
| `typo` | Spelling error | `NoResultsFound` | `NotFound.aiff` |
| `hyperlink` | Link | — | `LinkBegin.aiff` |
| `formatting` | Formatted text | — | `Capitals.aiff` |
| `screen_off` | Screen off | `ScreenDidTurnOff` | `iOSScreenOff.aiff` |
| `rotor_next` | Next setting | `DidSelectNextRotor` | `RotorRight.aiff` |
| `rotor_previous` | Previous setting | `DidSelectPreviousRotor` | `RotorLeft.aiff` |
| `keyboard_show` | Keyboard shown | `KeyboardAppeared` | `KeyboardUp.aiff` |
| `keyboard_hide` | Keyboard hidden | `KeyboardDisappeared` | `KeyboardDown.aiff` |
| `direct_touch_enter` | Direct touch on | `DidBeginPassthrough` | `Drill.aiff` |
| `wrap_forward` | Wrapped to the first item | `DidWrapForwards` | `WrapForward.aiff` |
| `wrap_back` | Wrapped to the last item | `DidWrapBackwards` | `WrapBack.aiff` |
| `loading` | Loading | `ItemIsLoading` | `WebPageLoadingInProgress.aiff` |
| `browse_mode_on_v4_2` | Browse mode on | `DidEnableQuickNav` | `TrackingOn.aiff` |
| `browse_mode_off_v4_2` | Browse mode off | `DidDisableQuickNav` | `TrackingOff.aiff` |
| `radial_menu` | Circle menu | — | `VOTOrbSound1-OrbHW.aiff` |
| `display_connected` | Braille display connected | — | `BrailleDisplayConnected.aiff` |
| `display_disconnected` | Braille display disconnected | — | `BrailleDisplayDisconnected.aiff` |
| `double_beep` | Braille command failed | `ItemMemorizationFailed` | `BrailleChordFailed.aiff` |
| `turn_on` | Braille auto scroll on | — | `TriggerSoundOn.aiff` |
| `turn_off` | Braille auto scroll off | — | `TriggerSoundOff.aiff` |
| `calibration_done` | Braille keyboard calibrated | `BSIDidCalibrate` | `BSICalibration.aiff` |
| `braille_keyboard_character` | Braille keyboard: character | `BSIDidType` | `BSITyping.aiff` |
| `braille_keyboard_space` | Braille keyboard: space | `BSIDidEnterSpace` | `BSISpace.aiff` |
| `braille_keyboard_delete` | Braille keyboard: delete | `BSIDidDelete` | `BSIDeletion.aiff` |
| `braille_keyboard_new_line` | Braille keyboard: new line | `BSIDidCarriageReturn` | `BSICarriageReturn.aiff` |

Swiping left or right moves the VoiceOver cursor, which is `focus`, so swiping
plays `ElementBorder.aiff`. `Focus.aiff` is **not** the swipe sound: VoiceOver
keeps it for `DidSyncWithSystemFocus`, when its cursor is pulled to wherever the
system moved focus, so this theme does not use it.

Backtalk plays `focus_actionable` instead of `focus` on anything you can act
on, but on iPhone every swipe sounds alike, so both are `ElementBorder.aiff`
here. `Interactable.aiff`, which VoiceOver keeps for `IsInteractable`, is not
what you hear when you swipe, so this theme does not use it either. The
difference is still there in the vibration, which is Apple's own haptic for an
interactable item.

`gesture_begin` and `gesture_end` are set to no sound, because VoiceOver plays
none for gestures.

`screen_on` and `direct_touch_exit` are left alone, so they stay silent as
Backtalk has them, since VoiceOver has no sound for either.

A dash in the VoiceOver event column means Backtalk has a sound where VoiceOver
has no matching event, so the nearest thing Apple ships stands in. Those eight,
and `typo`, which borrows VoiceOver's "nothing found" sound for want of a
misspelling one, are the ones to change first if they do not suit you: replace
any sound under **Sounds** in the theme's settings.

## Vibrations

The vibrations come from Apple's `.ahap` haptic patterns in the same app.
Apple's intensity became Backtalk's strength, and Apple's sharpness chose the
haptic primitive: sharp taps became `tick`, middling ones `click` and dull ones
`low_tick`. The two decaying buzzes, for a window change and the screen turning
off, became their intensity envelopes with a `quick_fall`.

| Backtalk vibration | Apple's pattern |
| --- | --- |
| `focus` | `DidFocusOnElement.ahap` |
| `focus_actionable` | `IsInteractable.ahap` |
| `tick` | `DidActivateElement.ahap` |
| `long_clicked` | `DidBeginPassthrough.ahap` |
| `scroll_tone` | `DidScrollByPage.ahap` |
| `chime_up` | `FolderDidOpen.ahap` |
| `chime_down` | `FolderDidClose.ahap` |
| `complete` | `BoundaryEncountered.ahap` |
| `window_state` | `ScreenDidChange.ahap` |
| `screen_off` | `ScreenDidTurnOff.ahap` |
| `loading` | `ItemIsLoading.ahap` |
| `typo` | `NoResultsFound.ahap` |
| `direct_touch_on` | `DidBeginPassthrough.ahap` |
| `announcement` | `NotificationDidAppear.ahap` |

Apple ships an empty haptic file where VoiceOver means to stay still, so
`chime_up` and `chime_down` have no vibration here.

VoiceOver also has haptics for the rotor, for wrapping, and for the keyboard
showing and hiding, but those sounds have no vibration in Backtalk, so a theme
cannot give them one. Every other vibration stays Backtalk's own.
